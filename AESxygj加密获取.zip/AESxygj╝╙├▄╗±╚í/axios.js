import axios from 'axios'
import dayjs from 'dayjs'
import md5 from 'js-md5'
import {h5Login} from './util'
import CryptoJS from 'crypto-js'
const uuid = require('uuid')
let xRequestId = ''

let partnerSecret = '041d0d40f99a557f6de7cbee523bae8a'
let partnerId = '42c4f1cbf33f6b1882496637fc588eb6'
// 本地环境固定aeskey，不走动态密钥 
let aesSecret = 'v24YXBYBNomIqAqrP50tDw=='
// 生产
// let domain = 'https://api-xygj.189smarthome.com'
// 测试 domain = 'http://121.229.54.36'
let domain = 'https://api-xygj.dlife.cn'
// 重查次数设置
let retry = 3
// 重查延时ms
let retryDelay = 1000

// 不做数据添加
const api = axios.create({
    baseURL: domain,
    timeout: 6000
  })
api.interceptors.request.use((config) => {
return config
}, () => {})
api.interceptors.response.use((response) => {
return response
}, () => {})

// 进行数据插入
const service = axios.create({
    baseURL: domain,
    timeout: 6000
})
service.interceptors.request.use((config) => {
    // config.headers['Access-Control-Max-Age'] = 86400
    config.headers = setHeader(config.headers)
    
    config.method === 'post' ? config.data = setGeneralParams(config.data, config.url) : config.params = {...config.params}
    return config
}, (error ) => {
    Promise.reject(error)
})

service.interceptors.response.use((response) => {
  // 添加请求次数系数
  response.config.requestCount = response.config.requestCount || 1
  let encryptParam = response.data.encryptParam || ''
  let tempUrl = response.config.url
  let isHasH5 = isHasH5Path(tempUrl)
  if(response.data.code === '20021'){
    if (response.config.requestCount < retry) {
      // 执行重查后，系数+1
      response.config.requestCount++
      // 重新登录
      h5Login()
      // 再次执行
      let turnAgain = new Promise(resolve => {
        setTimeout(() => {
          resolve();
        }, retryDelay || 100);
      });
      return turnAgain.then(() => {
        return service(response.config)
      });
    } else {
      return responseData()
    }
  }else{
    return responseData()
  }
  function responseData(){
    if(response.data.code === '0'){
      if(encryptParam !== ''){
        // return JSON.parse(decrypt(response.data.encryptParam, isHasH5));
        return response.data.encryptParam
      }else{
        return response.data.data;
      }
    }else{
      console.log(response.data.message)
    }
  }
},(error ) => {
  Promise.reject(error)
})
// 封装请求头
function setHeader (headers) {
    xRequestId = uuid.v4().replace(/-/g, '')
    const generalParam = {
        'content-type': 'application/json;charset=UTF-8',
        'grant-type': 'userToken',
        'x-request-id': xRequestId
    }
    const h5LoginToken = localStorage.getItem('h5LoginToken') || ''
    generalParam['xygj-token'] = h5LoginToken
    const headerParam = headers || {}
    const result = Object.assign(headerParam, generalParam)
    return result
}
// 封装请求参数
function setGeneralParams(params,url) {
    let isHasH5 = isHasH5Path(url)
    // 通过api接口获取并保存到localStorage
    let encryptParam = ''
    if(isHasH5){
      partnerSecret = '041d0d40f99a557f6de7cbee523bae8a'
      partnerId = '42c4f1cbf33f6b1882496637fc588eb6'
    }else{
      partnerSecret = localStorage.getItem('h5PartnerSecret') || partnerSecret
      partnerId = localStorage.getItem('h5PartnerId') || partnerId
      // encryptParam = encrypt(params, isHasH5) || ''
    }
    
    const sequenceNo = dayjs().format('YYYYMMDDHHmmssSSS')
    const h5LoginToken = localStorage.getItem('h5LoginToken') || ''
    
    const sign = h5LoginToken + sequenceNo + xRequestId + encryptParam + partnerSecret
    const signature = md5(sign)
    if(typeof(params) === 'string'){
      params=JSON.parse(params).parameter||{}
    }
    const generalParam = {
      'sequenceNo': sequenceNo,
      'partnerId': partnerId,
      'encryptParam': encryptParam,
      signature,
      'parameter': {
        ...params
      }
    }
    let paramStr = JSON.stringify(generalParam)
    return paramStr
  }

function isHasH5Path(url) {
    let tempStatus = url.includes('/h5/') || url.includes('/user/getXygjCode')
    return tempStatus
  }

  // 加密
  function encrypt(str, isHasH5) {
    let myAeskey = isHasH5 ? aesSecret : (localStorage.getItem('h5SecretKey') || aesSecret)
    let keyPara = CryptoJS.enc.Base64.parse(myAeskey)
    let srcs = JSON.stringify(str)
    let encrypted = CryptoJS.AES.encrypt(srcs, keyPara, {
      mode: CryptoJS.mode.ECB,
      padding: CryptoJS.pad.Pkcs7
    })
    let encryptedStr = encrypted.ciphertext.toString()
    return encryptedStr
  }

  // 解密
  function decrypt(str, isHasH5) {
    let myAeskey = isHasH5 ? aesSecret : (localStorage.getItem('h5SecretKey') || aesSecret)
    let key = CryptoJS.enc.Base64.parse(myAeskey)
    const encryptedHexStr = CryptoJS.enc.Hex.parse(str)
    const srcs = CryptoJS.enc.Base64.stringify(encryptedHexStr)
    let decrypt = CryptoJS.AES.decrypt(srcs, key, {
      mode: CryptoJS.mode.ECB,
      padding: CryptoJS.pad.Pkcs7
    })
    const decryptedStr = decrypt.toString(CryptoJS.enc.Utf8)
    return decryptedStr.toString()
  }

  export{
    api,
    service
  } 
