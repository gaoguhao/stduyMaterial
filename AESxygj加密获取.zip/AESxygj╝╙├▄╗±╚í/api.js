import { service } from './axios'
// 通过tyToken获取小翼管家登录信息,xygjToken有过期时间
export function getH5LoginToken(data) {
  return requestPost(
     '/rest/openapi/3.0/user/h5/login',
     data
  )
}
// 通过xygjToken获取获取xygjCode
export function getXygjCode(data) {
    return requestPost(
       '/model/rest/openapi/1.0/h5/digitalLife/getXygjCode',
       data
    )
}
// 通过xygjCode获取加密解密信息
export function getDynamicSecret(data) {
    return requestPost(
       '/model/rest/openapi/1.0/h5/digitalLife/getDynamicSecret',
       data
    )
}

// 云盘存储空间
export function getTyypSize(data){
    return requestPost(
       '/model/rest/openapi/1.0/h5/digitalLife/queryCloudDiskInfo',
       data
    )
}

// 189邮箱邮件数量
export function getMailCount(data){
    return requestPost(
        '/model/rest/openapi/1.0/h5/digitalLife/getMailCount',
        data
    )
}

// 获取健康数据
export function getHealthData(data){
    return requestPost(
        '/model/rest/openapi/1.0/h5/digitalLife/getHealthData',
        data
    )
}

//获取小翼管家数量
export function getXygjDeviceCount(data){
    return requestPost(
        '/model/rest/openapi/1.0/h5/digitalLife/queryDevOnlineNum',
        data
    )
}

  //获取tokencode
  export function getTokenCode(data){
    return requestPost(
        '/model/rest/openapi/1.0/h5/digitalLife/getTokenCode',
        data
    )
}
  //获取云盘H5登录页面
  export function getCloudDiskUrl(data){
    return requestPost(
        '/model/rest/openapi/1.0/h5/digitalLife/loginH5',
        data
    )
}
// 获取天翼看家数据
  export function getTykjDetails(data){
    return requestPost(
        '/model/rest/openapi/1.0/h5/digitalLife/queryPackageList',
        data
    )
}

function requestPost(url, data){
    return service.post(
        url,
        data,
        {
         headers: {
           'login-type': '1'
         }}
     )
}