import {
    getH5LoginToken,
    getXygjCode,
    getDynamicSecret
} from './api'

// 通过客户端tytoken获取xygjToken
export function h5Login() {
    return new Promise((resolve, reject) => {
        try {
            localStorage.removeItem('h5LoginToken')
            localStorage.removeItem('h5PartnerSecret')
            localStorage.removeItem('h5PartnerId')
        } catch (error) {
            
        }
        let tyToken = localStorage.getItem('h5TyToken')
        getH5LoginToken({tyToken}).then((resData) => {
                const h5LoginToken = resData.xygjToken
                localStorage.setItem('h5LoginToken', h5LoginToken)
                getUserInfoData().then(
                    res=>{
                        return resolve()
                    }
                )
        }).catch((error) => {
            return reject(error)
        })
    })
}

// 通过客户端xygjToken获取xygjCode后同步获取动态密钥，因为xygjcode在使用后就会失效，或者5分钟自动失效
export function getUserInfoData() {
    return new Promise((resolve, reject) => {
        getXygjCode().then((resData) => {
            const xygjCode = resData.xygjCode
            getDynamicSecret({xygjCode}).then((res)=>{
                let partnerSecret = res.partnerSecret
                let partnerId = res.partnerId
                let secretKey = res.secretKey
                localStorage.setItem('h5PartnerSecret', partnerSecret)
                localStorage.setItem('h5PartnerId', partnerId)
                localStorage.setItem('h5SecretKey', secretKey)
                return resolve()
            })
        }).catch((error) => {
            return reject()
        })
    })
}
